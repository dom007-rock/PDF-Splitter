# 🏪 Publishing PDF Splitter to the Microsoft Store

A complete, step-by-step guide to get your app from `.exe` to the Microsoft Store.

---

## 📋 Overview of what you need

| Item | Cost | Time |
|------|------|------|
| Microsoft Developer Account | $19 one-time | 5 min signup |
| Code Signing Certificate | Free (self-signed works for Store) | 5 min |
| MSIX Package | Free tooling | 15-30 min |
| Store Listing (screenshots, description) | Free | 30 min |
| Microsoft Review | Free | 1-3 business days |

**Total: ~$19 and a couple of hours of work.**

---

## Step 1: Register a Microsoft Developer Account

1. Go to: https://developer.microsoft.com/en-us/microsoft-store/register/
2. Sign in with your Microsoft account (or create one)
3. Choose **Individual** account type ($19 one-time)
4. Fill in your details and pay
5. Wait for approval (usually instant to a few hours)

Once approved, you'll have access to **Microsoft Partner Center** at:
https://partner.microsoft.com/dashboard

---

## Step 2: Reserve your app name

1. In **Partner Center** → click **Apps and Games** → **New product** → **App**
2. Reserve the name: **PDF Splitter** (or your preferred name)
   - If taken, try: "PDF Splitter Pro", "PDF Page Splitter", etc.
3. This reserves the name on the Store — no one else can use it

---

## Step 3: Build your .exe (already done! ✅)

You already have this from the `build.bat` script:
```
dist\PDF Splitter.exe
```

---

## Step 4: Create the MSIX package

### Option A: Use MSIX Packaging Tool (GUI — Recommended for beginners)

1. **Install** the MSIX Packaging Tool from the Microsoft Store:
   https://apps.microsoft.com/detail/9n5lw3jbcxkf

2. **Open** it and select **"Application package"** → **"Create your package on this computer"**

3. **Browse** to your `dist\PDF Splitter.exe`

4. Fill in the package info:
   - **Package name**: `PDFSplitter`
   - **Publisher name**: Must match your Partner Center publisher ID
     (Find it in Partner Center → Settings → Account settings → Organization profile)
     Format: `CN=XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX`
   - **Version**: `1.0.0.0`

5. **Run through the installer** — it will monitor file system and registry changes

6. **Save** the `.msix` file

### Option B: Use makeappx.exe (Command Line — More control)

This is what the included `package_msix.bat` script does. See below.

---

## Step 5: Prepare Store assets

You'll need these images for your Store listing:

| Asset | Size | Required |
|-------|------|----------|
| Store logo | 300 × 300 px | ✅ Yes |
| App icon | 150 × 150 px | ✅ Yes |
| Screenshot(s) | 1366 × 768 px (or 16:9) | ✅ Yes (at least 1) |
| Hero image | 1920 × 1080 px | Optional |
| Wide tile | 620 × 300 px | Optional |

**Tips:**
- Take screenshots of your app running (use Win + Shift + S)
- Use a clean, dark background for logos
- The red scissors ✂️ theme from the app works great as branding

---

## Step 6: Submit to the Store

1. Go to **Partner Center** → Your reserved app
2. Click **"Start your submission"**
3. Fill in each section:

### Pricing & availability
- **Price**: Free (or set a price)
- **Markets**: All markets (or select specific countries)

### Properties
- **Category**: Utilities & Tools
- **Subcategory**: File Management
- **Privacy policy URL**: You'll need a basic privacy policy page
  (Can be a simple GitHub Pages or any website)

### Age ratings
- Fill out the IARC questionnaire (takes 2 min)
- Your app will likely get rated "Everyone"

### Packages
- **Upload** your `.msix` file here
- Select architectures: x64 (and optionally x86, ARM64)

### Store listing
- **Description**: Write a compelling description
- **Screenshots**: Upload your screenshots
- **Search terms**: "pdf splitter, split pdf, pdf divider, pdf cutter"

4. Click **"Submit to the Store"**

---

## Step 7: Wait for review

- Microsoft reviews your app (1-3 business days)
- You'll get an email when it's approved or if changes are needed
- Common rejection reasons:
  - Missing privacy policy
  - App crashes on launch
  - Misleading screenshots
  - Description doesn't match functionality

---

## 📝 Store description template

Use this as a starting point:

```
PDF Splitter — Split any PDF into smaller files instantly.

✂️ Choose how many pages per file (2, 3, 5, 10, or any custom number)
📁 Automatically creates an organized output folder
📦 Save all split files as a single ZIP
📂 One-click to open the output folder

Perfect for:
• Splitting large documents into manageable chunks
• Breaking up scanned documents by section
• Preparing PDF submissions with page limits
• Organizing multi-page reports

Features:
• Drag & drop or browse for your PDF
• Custom page-per-file selector with presets
• Automatic output folder creation
• Save as ZIP for easy sharing
• Progress bar with live updates
• Beautiful dark theme interface
• Works completely offline — your files never leave your computer

Free. No ads. No signup. Just split.
```

---

## 📝 Privacy policy template

Host this on any webpage (GitHub Pages, your website, etc.):

```
Privacy Policy for PDF Splitter

Last updated: [DATE]

PDF Splitter is a desktop application that processes PDF files locally
on your computer.

Data Collection: We do not collect, store, or transmit any personal
data or files. All PDF processing happens entirely on your device.

Internet Access: The application does not require or use internet access.

Third-Party Services: The application does not use any third-party
analytics, advertising, or tracking services.

Contact: [YOUR EMAIL]
```

---

## ❓ FAQ

**Q: Can I publish for free?**
A: The developer account costs $19 one-time. After that, you can publish free apps at no extra cost.

**Q: Do I need a code signing certificate?**
A: For Store distribution, Microsoft signs the package during the submission process. You don't need to buy a separate certificate.

**Q: Can I update the app later?**
A: Yes! Submit a new package with an incremented version number through Partner Center.

**Q: How long until my app appears in the Store?**
A: After approval (1-3 days), it usually appears within 24 hours.

**Q: Can I charge for the app?**
A: Yes. You can set any price. Microsoft takes a 15% commission (12% for games).

---

## 🚀 Quick checklist

- [ ] Microsoft Developer Account ($19)
- [ ] Reserve app name in Partner Center
- [ ] Build .exe with build.bat
- [ ] Package as .msix
- [ ] Take screenshots (at least 1)
- [ ] Create app icon / logo (300x300)
- [ ] Write a privacy policy (host it online)
- [ ] Fill out Store listing
- [ ] Submit and wait for review
- [ ] 🎉 Celebrate when it's live!
