"""
Generate placeholder Store icons for MSIX packaging.
Replace these with proper designed icons before submitting!
"""
import os

try:
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtGui import QPixmap, QPainter, QColor, QFont
    from PyQt6.QtCore import Qt

    app = QApplication([])
    os.makedirs("assets", exist_ok=True)

    sizes = {
        "StoreLogo.png": (50, 50),
        "Square44x44Logo.png": (44, 44),
        "Square150x150Logo.png": (150, 150),
        "Square310x310Logo.png": (310, 310),
        "Wide310x150Logo.png": (310, 150),
    }

    for name, (w, h) in sizes.items():
        pm = QPixmap(w, h)
        pm.fill(QColor("#0e0e10"))
        p = QPainter(pm)
        p.setPen(QColor("#e74c3c"))
        font_size = max(10, min(w, h) // 4)
        font = QFont("Arial", font_size, QFont.Weight.Bold)
        p.setFont(font)
        p.drawText(pm.rect(), Qt.AlignmentFlag.AlignCenter, "PDF\nSplit")
        p.end()
        pm.save(os.path.join("assets", name))
        print(f"  Created: assets/{name} ({w}x{h})")

    print("\n  Placeholder icons created!")
    print("  Replace with proper designs before Store submission.")

except Exception as e:
    print(f"  Could not generate icons: {e}")
    print("  Create them manually in the assets/ folder.")
    os.makedirs("assets", exist_ok=True)
