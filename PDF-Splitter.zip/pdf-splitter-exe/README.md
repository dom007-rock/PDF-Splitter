# 🖥️ PDF Splitter — Single .exe Windows App

## 🚀 Quick Build (2 steps!)

### Prerequisites
- **Python 3.10+** → Download from https://python.org
  - ⚠️ During install, CHECK ✅ "Add Python to PATH"

### Build the .exe

1. **Extract** this folder anywhere on your PC
2. **Double-click** `build.bat`

That's it! Wait 1-3 minutes and your app appears at:
```
dist\PDF Splitter.exe
```

This is a **single portable .exe** — copy it anywhere, share with anyone. No Python needed to run it! 🎉

---

## ▶️ Or just run without building

If you have Python installed, you can run it directly:
```
pip install PyQt6 pypdf
python pdf_splitter.py
```

---

## 🎯 App Features

- 📂 **Drag & drop** or browse for PDF
- 🔢 **Choose pages per chunk** — presets (2, 3, 5, 10) or any custom number
- 📁 **Auto-creates output folder** — `YourPDF_split/` next to the original
- 📂 **Change output folder** if you want
- 📦 **Save as ZIP** — bundles everything into one file
- 📂 **Open Folder** — jump straight to the split files
- ⚡ **Progress bar** with live updates

---

## 📁 Files

```
pdf-splitter-exe/
├── pdf_splitter.py    ← The app (Python source)
├── build.bat          ← Double-click to build .exe
└── README.md          ← You are here
```

After building:
```
dist/
└── PDF Splitter.exe   ← Your single-file app!
```
