@echo off
echo ==========================================
echo    PDF Splitter - MSIX Packager
echo ==========================================
echo.

:: Check if .exe exists
if not exist "dist\PDF Splitter.exe" (
    echo ERROR: "dist\PDF Splitter.exe" not found!
    echo Run build.bat first to create the .exe
    pause
    exit /b 1
)

:: Check if makeappx is available
where makeappx >nul 2>&1
if errorlevel 1 (
    echo ==========================================
    echo  makeappx.exe not found in PATH!
    echo.
    echo  Install the Windows SDK:
    echo  https://developer.microsoft.com/en-us/windows/downloads/windows-sdk/
    echo.
    echo  During install, check:
    echo    [x] Windows SDK Signing Tools
    echo.
    echo  Then add to PATH:
    echo  C:\Program Files (x86)\Windows Kits\10\bin\10.0.xxxxx.0\x64
    echo.
    echo  OR use the MSIX Packaging Tool (GUI) instead:
    echo  https://apps.microsoft.com/detail/9n5lw3jbcxkf
    echo ==========================================
    pause
    exit /b 1
)

echo [1/4] Preparing package folder...
if exist "msix_staging" rmdir /s /q "msix_staging"
mkdir msix_staging
mkdir msix_staging\assets

echo [2/4] Copying files...
copy "dist\PDF Splitter.exe" "msix_staging\" >nul
copy "AppxManifest.xml" "msix_staging\" >nul

:: Check for asset files
if exist "assets\StoreLogo.png" (
    copy "assets\*" "msix_staging\assets\" >nul
    echo    Assets copied.
) else (
    echo.
    echo ==========================================
    echo  WARNING: Asset images not found!
    echo.
    echo  Create an "assets" folder with these PNGs:
    echo    assets\StoreLogo.png         (50x50)
    echo    assets\Square44x44Logo.png   (44x44)
    echo    assets\Square150x150Logo.png (150x150)
    echo    assets\Square310x310Logo.png (310x310)
    echo    assets\Wide310x150Logo.png   (310x150)
    echo.
    echo  For now, creating placeholder files...
    echo ==========================================
    echo.
    python create_placeholder_icons.py
    copy "assets\*" "msix_staging\assets\" >nul
)

echo [3/4] Have you edited AppxManifest.xml?
echo.
echo    You MUST update these values:
echo    - Publisher: CN=YOUR-PUBLISHER-ID
echo    - Name: YourPublisherName.PDFSplitter
echo    - PublisherDisplayName: Your Name
echo.
set /p CONFIRM="Continue anyway? (y/n): "
if /i not "%CONFIRM%"=="y" (
    echo.
    echo Edit AppxManifest.xml and run this script again.
    pause
    exit /b 0
)

echo.
echo [4/4] Creating MSIX package...
makeappx pack /d msix_staging /p "PDF_Splitter.msix" /o

if exist "PDF_Splitter.msix" (
    echo.
    echo ==========================================
    echo   MSIX PACKAGE CREATED!
    echo   File: PDF_Splitter.msix
    echo.
    echo   Next steps:
    echo   1. Go to Partner Center
    echo   2. Upload PDF_Splitter.msix
    echo   3. Fill in Store listing
    echo   4. Submit for review
    echo ==========================================
) else (
    echo.
    echo   PACKAGING FAILED - see errors above
)
echo.
pause
