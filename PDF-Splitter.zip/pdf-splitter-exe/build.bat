@echo off
echo ==========================================
echo    PDF Splitter - Build to .exe
echo ==========================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found! Install from https://python.org
    pause
    exit /b 1
)

echo [1/3] Installing dependencies...
pip install PyQt6 pypdf pyinstaller --quiet --upgrade

echo.
echo [2/3] Finding PyQt6 plugin path...

:: Get PyQt6 plugins path dynamically
for /f "delims=" %%i in ('python -c "import os, PyQt6; print(os.path.join(os.path.dirname(PyQt6.__file__), 'Qt6', 'plugins'))"') do set QT_PLUGINS=%%i

echo    Found: %QT_PLUGINS%

echo.
echo [3/3] Building single .exe (this takes 1-3 minutes)...

pyinstaller --onefile --windowed --name "PDF Splitter" --clean ^
  --add-data "%QT_PLUGINS%\platforms;PyQt6\Qt6\plugins\platforms" ^
  --add-data "%QT_PLUGINS%\styles;PyQt6\Qt6\plugins\styles" ^
  --hidden-import PyQt6.QtCore ^
  --hidden-import PyQt6.QtGui ^
  --hidden-import PyQt6.QtWidgets ^
  --hidden-import PyQt6.sip ^
  pdf_splitter.py

echo.
if exist "dist\PDF Splitter.exe" (
    echo ==========================================
    echo   BUILD COMPLETE!
    echo   Your .exe is in: dist\PDF Splitter.exe
    echo ==========================================
) else (
    echo ==========================================
    echo   BUILD FAILED - see errors above
    echo ==========================================
)
echo.
pause
