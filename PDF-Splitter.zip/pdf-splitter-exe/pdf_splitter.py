"""
PDF Splitter — Desktop App
Split PDFs into custom-sized chunks and save to a folder or ZIP.
Built with PyQt6 + pypdf. Compile with PyInstaller for a single .exe.
"""

import sys
import os
import zipfile
from pathlib import Path

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QFileDialog, QSpinBox, QProgressBar,
    QScrollArea, QFrame, QMessageBox, QSizePolicy
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QColor, QPalette, QIcon, QDragEnterEvent, QDropEvent

from pypdf import PdfReader, PdfWriter


# ── Worker Thread ──────────────────────────────────────────────
class SplitWorker(QThread):
    progress = pyqtSignal(int, str)     # (percent, current_file_name)
    finished = pyqtSignal(list)         # list of output file paths
    error = pyqtSignal(str)

    def __init__(self, input_path, chunk_size, output_dir):
        super().__init__()
        self.input_path = input_path
        self.chunk_size = chunk_size
        self.output_dir = output_dir

    def run(self):
        try:
            reader = PdfReader(self.input_path)
            total = len(reader.pages)
            if total == 0:
                self.error.emit("PDF has no pages.")
                return

            os.makedirs(self.output_dir, exist_ok=True)
            output_files = []
            chunks_total = -(-total // self.chunk_size)  # ceil division

            for idx, start in enumerate(range(0, total, self.chunk_size)):
                end = min(start + self.chunk_size, total)
                writer = PdfWriter()
                for p in range(start, end):
                    writer.add_page(reader.pages[p])

                name = f"{start + 1}-{end}.pdf"
                out_path = os.path.join(self.output_dir, name)
                with open(out_path, "wb") as f:
                    writer.write(f)

                output_files.append(out_path)
                pct = int((idx + 1) / chunks_total * 100)
                self.progress.emit(pct, name)

            self.finished.emit(output_files)
        except Exception as e:
            self.error.emit(str(e))


# ── Styles ─────────────────────────────────────────────────────
STYLE = """
QMainWindow {
    background-color: #0e0e10;
}
QWidget#central {
    background-color: #0e0e10;
}
QLabel {
    color: #f0ece6;
}
QLabel#subtitle {
    color: #777777;
    font-size: 13px;
}
QLabel#title {
    font-size: 28px;
    font-weight: 300;
    color: #f0ece6;
    padding-top: 8px;
}
QLabel#dropLabel {
    color: #888888;
    font-size: 14px;
}
QLabel#fileLabel {
    color: #f0ece6;
    font-size: 14px;
    font-weight: 600;
}
QLabel#sizeLabel {
    color: #777;
    font-size: 12px;
}
QLabel#sectionLabel {
    color: #cccccc;
    font-size: 13px;
    font-weight: 600;
}

/* Drop zone */
QFrame#dropZone {
    border: 2px dashed #2a2a2e;
    border-radius: 14px;
    background-color: rgba(255, 255, 255, 2);
    padding: 36px;
}
QFrame#dropZone:hover {
    border-color: #e74c3c;
    background-color: rgba(231, 76, 60, 10);
}

/* File card */
QFrame#fileCard {
    background-color: rgba(255, 255, 255, 8);
    border: 1px solid #2a2a2e;
    border-radius: 12px;
    padding: 14px 18px;
}

/* Chunk section */
QFrame#chunkFrame {
    background-color: rgba(255, 255, 255, 5);
    border: 1px solid #2a2a2e;
    border-radius: 12px;
    padding: 16px;
}

/* SpinBox */
QSpinBox {
    background-color: #1a1a1e;
    color: #e74c3c;
    border: 1px solid rgba(231, 76, 60, 80);
    border-radius: 8px;
    padding: 6px 12px;
    font-size: 14px;
    font-weight: 600;
    min-width: 80px;
}
QSpinBox::up-button, QSpinBox::down-button {
    width: 20px;
    border: none;
    background: rgba(231, 76, 60, 30);
}
QSpinBox::up-arrow { image: none; border-left: 5px solid transparent; border-right: 5px solid transparent; border-bottom: 6px solid #e74c3c; }
QSpinBox::down-arrow { image: none; border-left: 5px solid transparent; border-right: 5px solid transparent; border-top: 6px solid #e74c3c; }

/* Preset buttons */
QPushButton.preset {
    background-color: rgba(255, 255, 255, 10);
    color: #999999;
    border: 1px solid #2a2a2e;
    border-radius: 8px;
    padding: 7px 16px;
    font-size: 13px;
    font-weight: 600;
    min-width: 42px;
}
QPushButton.preset:hover {
    background-color: rgba(231, 76, 60, 25);
    color: #e74c3c;
    border-color: rgba(231, 76, 60, 80);
}
QPushButton.preset:checked {
    background-color: rgba(231, 76, 60, 30);
    color: #e74c3c;
    border-color: rgba(231, 76, 60, 90);
}

/* Primary button */
QPushButton#splitBtn {
    background-color: #e74c3c;
    color: white;
    border: none;
    border-radius: 10px;
    padding: 13px 0px;
    font-size: 15px;
    font-weight: 600;
}
QPushButton#splitBtn:hover {
    background-color: #c0392b;
}
QPushButton#splitBtn:disabled {
    background-color: rgba(231, 76, 60, 120);
}

/* Browse button */
QPushButton#browseBtn {
    background-color: rgba(231, 76, 60, 25);
    color: #e74c3c;
    border: 1px solid rgba(231, 76, 60, 50);
    border-radius: 8px;
    padding: 9px 22px;
    font-size: 13px;
    font-weight: 600;
}
QPushButton#browseBtn:hover {
    background-color: rgba(231, 76, 60, 45);
}

/* Secondary buttons */
QPushButton#zipBtn {
    background-color: rgba(46, 204, 113, 30);
    color: #2ecc71;
    border: 1px solid rgba(46, 204, 113, 70);
    border-radius: 8px;
    padding: 8px 16px;
    font-size: 12px;
    font-weight: 600;
}
QPushButton#zipBtn:hover {
    background-color: rgba(46, 204, 113, 55);
}

QPushButton#openFolderBtn {
    background-color: rgba(52, 152, 219, 30);
    color: #3498db;
    border: 1px solid rgba(52, 152, 219, 70);
    border-radius: 8px;
    padding: 8px 16px;
    font-size: 12px;
    font-weight: 600;
}
QPushButton#openFolderBtn:hover {
    background-color: rgba(52, 152, 219, 55);
}

QPushButton#resetBtn {
    background-color: rgba(255, 255, 255, 15);
    color: #aaaaaa;
    border: 1px solid #2a2a2e;
    border-radius: 8px;
    padding: 8px 16px;
    font-size: 12px;
    font-weight: 600;
}
QPushButton#resetBtn:hover {
    background-color: rgba(255, 255, 255, 30);
}

QPushButton#removeBtn {
    background: none;
    border: none;
    color: #666;
    font-size: 16px;
    padding: 4px;
}
QPushButton#removeBtn:hover {
    color: #e74c3c;
}

/* Progress bar */
QProgressBar {
    background-color: #1a1a1e;
    border: 1px solid #2a2a2e;
    border-radius: 6px;
    text-align: center;
    color: #f0ece6;
    font-size: 11px;
    height: 22px;
}
QProgressBar::chunk {
    background-color: #e74c3c;
    border-radius: 5px;
}

/* Results area */
QFrame#resultItem {
    background-color: transparent;
    border-bottom: 1px solid #1a1a1e;
    padding: 8px 14px;
}
QFrame#resultItem:hover {
    background-color: rgba(231, 76, 60, 15);
}

QScrollArea {
    border: 1px solid #2a2a2e;
    border-radius: 12px;
    background-color: transparent;
}
QScrollArea > QWidget > QWidget {
    background-color: transparent;
}
QScrollBar:vertical {
    background: #1a1a1e;
    width: 8px;
    border-radius: 4px;
}
QScrollBar::handle:vertical {
    background: #333;
    border-radius: 4px;
    min-height: 30px;
}
"""


# ── Main Window ────────────────────────────────────────────────
class PDFSplitterApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PDF Splitter")
        self.setMinimumSize(520, 620)
        self.resize(540, 700)
        self.setAcceptDrops(True)
        self.setStyleSheet(STYLE)

        self.current_file = None
        self.output_files = []
        self.output_dir = None

        self._build_ui()

    def _build_ui(self):
        central = QWidget()
        central.setObjectName("central")
        self.setCentralWidget(central)

        root = QVBoxLayout(central)
        root.setContentsMargins(32, 28, 32, 28)
        root.setSpacing(0)
        root.setAlignment(Qt.AlignmentFlag.AlignTop)

        # ── Header ──
        header = QVBoxLayout()
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header.setSpacing(4)

        title = QLabel("✂️  PDF Splitter")
        title.setObjectName("title")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header.addWidget(title)

        subtitle = QLabel("Split your PDF into custom-sized chunks")
        subtitle.setObjectName("subtitle")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header.addWidget(subtitle)

        root.addLayout(header)
        root.addSpacing(24)

        # ── Drop zone ──
        self.drop_zone = QFrame()
        self.drop_zone.setObjectName("dropZone")
        self.drop_zone.setCursor(Qt.CursorShape.PointingHandCursor)
        dz_layout = QVBoxLayout(self.drop_zone)
        dz_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dz_layout.setSpacing(8)

        drop_icon = QLabel("📄")
        drop_icon.setStyleSheet("font-size: 36px;")
        drop_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dz_layout.addWidget(drop_icon)

        drop_text = QLabel("Drag & drop your PDF here")
        drop_text.setObjectName("dropLabel")
        drop_text.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dz_layout.addWidget(drop_text)

        or_label = QLabel("or")
        or_label.setStyleSheet("color: #555; font-size: 12px;")
        or_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dz_layout.addWidget(or_label)

        browse_btn = QPushButton("Browse Files")
        browse_btn.setObjectName("browseBtn")
        browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        browse_btn.clicked.connect(self._browse_file)
        browse_btn.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        dz_layout.addWidget(browse_btn, alignment=Qt.AlignmentFlag.AlignCenter)

        root.addWidget(self.drop_zone)

        # ── File card (hidden initially) ──
        self.file_card = QFrame()
        self.file_card.setObjectName("fileCard")
        self.file_card.setVisible(False)
        fc_layout = QHBoxLayout(self.file_card)
        fc_layout.setContentsMargins(0, 0, 0, 0)

        fc_left = QVBoxLayout()
        fc_left.setSpacing(2)
        self.file_name_label = QLabel("")
        self.file_name_label.setObjectName("fileLabel")
        fc_left.addWidget(self.file_name_label)
        self.file_size_label = QLabel("")
        self.file_size_label.setObjectName("sizeLabel")
        fc_left.addWidget(self.file_size_label)
        fc_layout.addLayout(fc_left, stretch=1)

        remove_btn = QPushButton("✕")
        remove_btn.setObjectName("removeBtn")
        remove_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        remove_btn.clicked.connect(self._reset)
        fc_layout.addWidget(remove_btn)

        root.addWidget(self.file_card)

        # ── Chunk size section (hidden initially) ──
        self.chunk_frame = QFrame()
        self.chunk_frame.setObjectName("chunkFrame")
        self.chunk_frame.setVisible(False)
        cf_layout = QVBoxLayout(self.chunk_frame)
        cf_layout.setSpacing(10)

        cl = QLabel("Pages per file")
        cl.setObjectName("sectionLabel")
        cf_layout.addWidget(cl)

        row = QHBoxLayout()
        row.setSpacing(8)

        for n in [2, 3, 5, 10]:
            btn = QPushButton(str(n))
            btn.setProperty("class", "preset")
            btn.setCheckable(True)
            btn.setChecked(n == 3)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda checked, v=n: self._set_chunk(v))
            row.addWidget(btn)

        self.chunk_spin = QSpinBox()
        self.chunk_spin.setRange(1, 500)
        self.chunk_spin.setValue(3)
        self.chunk_spin.setToolTip("Custom page count")
        self.chunk_spin.valueChanged.connect(self._on_spin_change)
        row.addWidget(self.chunk_spin)
        row.addStretch()

        cf_layout.addLayout(row)

        self.chunk_hint = QLabel("Each file will contain 3 pages")
        self.chunk_hint.setStyleSheet("color: #555; font-size: 11px;")
        cf_layout.addWidget(self.chunk_hint)

        root.addSpacing(12)
        root.addWidget(self.chunk_frame)

        # ── Output folder selector ──
        self.output_frame = QFrame()
        self.output_frame.setObjectName("chunkFrame")
        self.output_frame.setVisible(False)
        of_layout = QVBoxLayout(self.output_frame)
        of_layout.setSpacing(8)

        ol = QLabel("Save to folder")
        ol.setObjectName("sectionLabel")
        of_layout.addWidget(ol)

        of_row = QHBoxLayout()
        self.output_label = QLabel("Default: same folder as PDF")
        self.output_label.setStyleSheet("color: #888; font-size: 12px; font-family: monospace;")
        self.output_label.setWordWrap(True)
        of_row.addWidget(self.output_label, stretch=1)

        choose_btn = QPushButton("Change")
        choose_btn.setObjectName("browseBtn")
        choose_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        choose_btn.clicked.connect(self._choose_output_dir)
        of_row.addWidget(choose_btn)
        of_layout.addLayout(of_row)

        root.addSpacing(8)
        root.addWidget(self.output_frame)

        # ── Split button ──
        self.split_btn = QPushButton("✂️  Split PDF")
        self.split_btn.setObjectName("splitBtn")
        self.split_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.split_btn.setVisible(False)
        self.split_btn.clicked.connect(self._start_split)
        root.addSpacing(16)
        root.addWidget(self.split_btn)

        # ── Progress bar ──
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setTextVisible(True)
        root.addSpacing(8)
        root.addWidget(self.progress_bar)

        # ── Results section ──
        self.results_widget = QWidget()
        self.results_widget.setVisible(False)
        rw_layout = QVBoxLayout(self.results_widget)
        rw_layout.setContentsMargins(0, 0, 0, 0)
        rw_layout.setSpacing(10)

        # Result header
        rh = QHBoxLayout()
        self.result_title = QLabel("")
        self.result_title.setStyleSheet("color: #f0ece6; font-size: 17px; font-weight: 600;")
        rh.addWidget(self.result_title)
        rh.addStretch()
        rw_layout.addLayout(rh)

        self.folder_hint = QLabel("")
        self.folder_hint.setStyleSheet("color: #666; font-size: 12px; font-family: monospace;")
        self.folder_hint.setWordWrap(True)
        rw_layout.addWidget(self.folder_hint)

        # Action buttons row
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        self.zip_btn = QPushButton("📦 Save as ZIP")
        self.zip_btn.setObjectName("zipBtn")
        self.zip_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.zip_btn.clicked.connect(self._save_zip)
        btn_row.addWidget(self.zip_btn)

        self.open_folder_btn = QPushButton("📂 Open Folder")
        self.open_folder_btn.setObjectName("openFolderBtn")
        self.open_folder_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.open_folder_btn.clicked.connect(self._open_folder)
        btn_row.addWidget(self.open_folder_btn)

        self.reset_btn = QPushButton("↻ New PDF")
        self.reset_btn.setObjectName("resetBtn")
        self.reset_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.reset_btn.clicked.connect(self._reset)
        btn_row.addWidget(self.reset_btn)
        btn_row.addStretch()

        rw_layout.addLayout(btn_row)

        # Result file list
        self.result_scroll = QScrollArea()
        self.result_scroll.setWidgetResizable(True)
        self.result_scroll.setMaximumHeight(220)
        self.result_list_widget = QWidget()
        self.result_list_layout = QVBoxLayout(self.result_list_widget)
        self.result_list_layout.setContentsMargins(0, 0, 0, 0)
        self.result_list_layout.setSpacing(0)
        self.result_scroll.setWidget(self.result_list_widget)
        rw_layout.addWidget(self.result_scroll)

        root.addSpacing(12)
        root.addWidget(self.results_widget)
        root.addStretch()

    # ── Drag & Drop ──
    def dragEnterEvent(self, event: QDragEnterEvent):
        if event.mimeData().hasUrls():
            urls = event.mimeData().urls()
            if urls and urls[0].toLocalFile().lower().endswith('.pdf'):
                event.acceptProposedAction()

    def dropEvent(self, event: QDropEvent):
        urls = event.mimeData().urls()
        if urls:
            path = urls[0].toLocalFile()
            if path.lower().endswith('.pdf'):
                self._load_file(path)

    # ── File handling ──
    def _browse_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select PDF", "", "PDF Files (*.pdf)")
        if path:
            self._load_file(path)

    def _load_file(self, path):
        self.current_file = path
        name = os.path.basename(path)
        size_mb = os.path.getsize(path) / (1024 * 1024)

        self.file_name_label.setText(f"📄 {name}")
        self.file_size_label.setText(f"{size_mb:.2f} MB")

        # Set default output dir
        base = Path(path).stem
        self.output_dir = os.path.join(os.path.dirname(path), f"{base}_split")
        self.output_label.setText(self.output_dir)

        self.drop_zone.setVisible(False)
        self.file_card.setVisible(True)
        self.chunk_frame.setVisible(True)
        self.output_frame.setVisible(True)
        self.split_btn.setVisible(True)
        self.results_widget.setVisible(False)

    def _choose_output_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Choose Output Folder")
        if d:
            self.output_dir = d
            self.output_label.setText(d)

    # ── Chunk size ──
    def _set_chunk(self, value):
        self.chunk_spin.setValue(value)
        # Update preset button states
        for btn in self.chunk_frame.findChildren(QPushButton):
            if btn.property("class") == "preset":
                btn.setChecked(btn.text() == str(value))

    def _on_spin_change(self, value):
        self.chunk_hint.setText(f"Each file will contain {value} page{'s' if value != 1 else ''}")
        for btn in self.chunk_frame.findChildren(QPushButton):
            if btn.property("class") == "preset":
                btn.setChecked(btn.text() == str(value))

    # ── Split ──
    def _start_split(self):
        if not self.current_file:
            return

        self.split_btn.setEnabled(False)
        self.split_btn.setText("⏳ Splitting...")
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)

        self.worker = SplitWorker(
            self.current_file,
            self.chunk_spin.value(),
            self.output_dir
        )
        self.worker.progress.connect(self._on_progress)
        self.worker.finished.connect(self._on_finished)
        self.worker.error.connect(self._on_error)
        self.worker.start()

    def _on_progress(self, pct, name):
        self.progress_bar.setValue(pct)
        self.progress_bar.setFormat(f"Creating {name}... {pct}%")

    def _on_finished(self, files):
        self.output_files = files
        self.progress_bar.setVisible(False)
        self.split_btn.setVisible(False)
        self.file_card.setVisible(False)
        self.chunk_frame.setVisible(False)
        self.output_frame.setVisible(False)

        self.result_title.setText(f"🎉 Split into {len(files)} files")
        self.folder_hint.setText(f"📁 {self.output_dir}")

        # Clear old results
        while self.result_list_layout.count():
            item = self.result_list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        for f in files:
            name = os.path.basename(f)
            item = QFrame()
            item.setObjectName("resultItem")
            item.setStyleSheet("padding: 6px 12px; border-bottom: 1px solid #1a1a1e;")
            hl = QHBoxLayout(item)
            hl.setContentsMargins(0, 0, 0, 0)
            lbl = QLabel(f"📄 {name}")
            lbl.setStyleSheet("color: #f0ece6; font-size: 13px;")
            hl.addWidget(lbl)
            hl.addStretch()
            self.result_list_layout.addWidget(item)

        self.result_list_layout.addStretch()
        self.results_widget.setVisible(True)

    def _on_error(self, msg):
        self.progress_bar.setVisible(False)
        self.split_btn.setEnabled(True)
        self.split_btn.setText("✂️  Split PDF")
        QMessageBox.critical(self, "Error", f"Failed to split PDF:\n{msg}")

    # ── Actions ──
    def _save_zip(self):
        base = Path(self.current_file).stem if self.current_file else "split"
        default_name = f"{base}_split.zip"
        path, _ = QFileDialog.getSaveFileName(self, "Save ZIP", default_name, "ZIP Files (*.zip)")
        if not path:
            return
        try:
            with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as zf:
                folder_name = f"{base}_split"
                for f in self.output_files:
                    zf.write(f, os.path.join(folder_name, os.path.basename(f)))
            QMessageBox.information(self, "Saved!", f"ZIP saved to:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to create ZIP:\n{e}")

    def _open_folder(self):
        if self.output_dir and os.path.isdir(self.output_dir):
            if sys.platform == "win32":
                os.startfile(self.output_dir)
            elif sys.platform == "darwin":
                os.system(f'open "{self.output_dir}"')
            else:
                os.system(f'xdg-open "{self.output_dir}"')

    def _reset(self):
        self.current_file = None
        self.output_files = []
        self.output_dir = None

        self.drop_zone.setVisible(True)
        self.file_card.setVisible(False)
        self.chunk_frame.setVisible(False)
        self.output_frame.setVisible(False)
        self.split_btn.setVisible(False)
        self.split_btn.setEnabled(True)
        self.split_btn.setText("✂️  Split PDF")
        self.progress_bar.setVisible(False)
        self.results_widget.setVisible(False)

        self.chunk_spin.setValue(3)
        self._set_chunk(3)


# ── Entry Point ────────────────────────────────────────────────
def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    # Dark palette
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor("#0e0e10"))
    palette.setColor(QPalette.ColorRole.WindowText, QColor("#f0ece6"))
    palette.setColor(QPalette.ColorRole.Base, QColor("#1a1a1e"))
    palette.setColor(QPalette.ColorRole.Text, QColor("#f0ece6"))
    palette.setColor(QPalette.ColorRole.Button, QColor("#2a2a2e"))
    palette.setColor(QPalette.ColorRole.ButtonText, QColor("#f0ece6"))
    palette.setColor(QPalette.ColorRole.Highlight, QColor("#e74c3c"))
    app.setPalette(palette)

    window = PDFSplitterApp()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
